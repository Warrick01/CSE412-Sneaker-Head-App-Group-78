--
-- PostgreSQL database dump
--

-- Dumped from database version 14.9 (Ubuntu 14.9-0ubuntu0.22.04.1)
-- Dumped by pg_dump version 14.9 (Ubuntu 14.9-0ubuntu0.22.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: Order; Type: TABLE; Schema: public; Owner: possum
--

CREATE TABLE public."Order" (
    order_id integer NOT NULL,
    status character varying(255),
    date date
);


ALTER TABLE public."Order" OWNER TO possum;

--
-- Name: Order_order_id_seq; Type: SEQUENCE; Schema: public; Owner: possum
--

CREATE SEQUENCE public."Order_order_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Order_order_id_seq" OWNER TO possum;

--
-- Name: Order_order_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: possum
--

ALTER SEQUENCE public."Order_order_id_seq" OWNED BY public."Order".order_id;


--
-- Name: User; Type: TABLE; Schema: public; Owner: possum
--

CREATE TABLE public."User" (
    username character varying(255) NOT NULL,
    password character varying(255) NOT NULL,
    name character varying(255),
    birthday date,
    email character varying(255),
    preferred_size character varying(50)
);


ALTER TABLE public."User" OWNER TO possum;

--
-- Name: listing; Type: TABLE; Schema: public; Owner: possum
--

CREATE TABLE public.listing (
    listing_id integer NOT NULL,
    size character varying(50),
    shoe_sku character varying(255),
    description text,
    price numeric(10,2),
    date date
);


ALTER TABLE public.listing OWNER TO possum;

--
-- Name: listing_listing_id_seq; Type: SEQUENCE; Schema: public; Owner: possum
--

CREATE SEQUENCE public.listing_listing_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.listing_listing_id_seq OWNER TO possum;

--
-- Name: listing_listing_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: possum
--

ALTER SEQUENCE public.listing_listing_id_seq OWNED BY public.listing.listing_id;


--
-- Name: order_shipment; Type: TABLE; Schema: public; Owner: possum
--

CREATE TABLE public.order_shipment (
    order_id integer NOT NULL,
    shipment_id integer NOT NULL
);


ALTER TABLE public.order_shipment OWNER TO possum;

--
-- Name: review; Type: TABLE; Schema: public; Owner: possum
--

CREATE TABLE public.review (
    review_id integer NOT NULL,
    text text,
    rating integer
);


ALTER TABLE public.review OWNER TO possum;

--
-- Name: review_review_id_seq; Type: SEQUENCE; Schema: public; Owner: possum
--

CREATE SEQUENCE public.review_review_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.review_review_id_seq OWNER TO possum;

--
-- Name: review_review_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: possum
--

ALTER SEQUENCE public.review_review_id_seq OWNED BY public.review.review_id;


--
-- Name: sale_history; Type: TABLE; Schema: public; Owner: possum
--

CREATE TABLE public.sale_history (
    shoe_sku character varying(255),
    name character varying(255)
);


ALTER TABLE public.sale_history OWNER TO possum;

--
-- Name: shipment; Type: TABLE; Schema: public; Owner: possum
--

CREATE TABLE public.shipment (
    shipment_id integer NOT NULL,
    tracking_number character varying(255),
    address character varying(255),
    distributor character varying(255)
);


ALTER TABLE public.shipment OWNER TO possum;

--
-- Name: shipment_shipment_id_seq; Type: SEQUENCE; Schema: public; Owner: possum
--

CREATE SEQUENCE public.shipment_shipment_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.shipment_shipment_id_seq OWNER TO possum;

--
-- Name: shipment_shipment_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: possum
--

ALTER SEQUENCE public.shipment_shipment_id_seq OWNED BY public.shipment.shipment_id;


--
-- Name: shoe; Type: TABLE; Schema: public; Owner: possum
--

CREATE TABLE public.shoe (
    shoe_sku character varying(255) NOT NULL,
    quality character varying(50),
    lowest_listing_price numeric(10,2),
    manufacturer character varying(255)
);


ALTER TABLE public.shoe OWNER TO possum;

--
-- Name: transaction; Type: TABLE; Schema: public; Owner: possum
--

CREATE TABLE public.transaction (
    transaction_id integer NOT NULL,
    sold_price numeric(10,2),
    date date,
    buyer_username character varying(255),
    seller_username character varying(255)
);


ALTER TABLE public.transaction OWNER TO possum;

--
-- Name: transaction_transaction_id_seq; Type: SEQUENCE; Schema: public; Owner: possum
--

CREATE SEQUENCE public.transaction_transaction_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.transaction_transaction_id_seq OWNER TO possum;

--
-- Name: transaction_transaction_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: possum
--

ALTER SEQUENCE public.transaction_transaction_id_seq OWNED BY public.transaction.transaction_id;


--
-- Name: user_buys_listing; Type: TABLE; Schema: public; Owner: possum
--

CREATE TABLE public.user_buys_listing (
    username character varying(255) NOT NULL,
    listing_id integer NOT NULL
);


ALTER TABLE public.user_buys_listing OWNER TO possum;

--
-- Name: user_posts_listing; Type: TABLE; Schema: public; Owner: possum
--

CREATE TABLE public.user_posts_listing (
    username character varying(255) NOT NULL,
    listing_id integer NOT NULL
);


ALTER TABLE public.user_posts_listing OWNER TO possum;

--
-- Name: user_reviews; Type: TABLE; Schema: public; Owner: possum
--

CREATE TABLE public.user_reviews (
    username character varying(255) NOT NULL,
    review_id integer NOT NULL
);


ALTER TABLE public.user_reviews OWNER TO possum;

--
-- Name: Order order_id; Type: DEFAULT; Schema: public; Owner: possum
--

ALTER TABLE ONLY public."Order" ALTER COLUMN order_id SET DEFAULT nextval('public."Order_order_id_seq"'::regclass);


--
-- Name: listing listing_id; Type: DEFAULT; Schema: public; Owner: possum
--

ALTER TABLE ONLY public.listing ALTER COLUMN listing_id SET DEFAULT nextval('public.listing_listing_id_seq'::regclass);


--
-- Name: review review_id; Type: DEFAULT; Schema: public; Owner: possum
--

ALTER TABLE ONLY public.review ALTER COLUMN review_id SET DEFAULT nextval('public.review_review_id_seq'::regclass);


--
-- Name: shipment shipment_id; Type: DEFAULT; Schema: public; Owner: possum
--

ALTER TABLE ONLY public.shipment ALTER COLUMN shipment_id SET DEFAULT nextval('public.shipment_shipment_id_seq'::regclass);


--
-- Name: transaction transaction_id; Type: DEFAULT; Schema: public; Owner: possum
--

ALTER TABLE ONLY public.transaction ALTER COLUMN transaction_id SET DEFAULT nextval('public.transaction_transaction_id_seq'::regclass);


--
-- Data for Name: Order; Type: TABLE DATA; Schema: public; Owner: possum
--

COPY public."Order" (order_id, status, date) FROM stdin;
76250	Verifying	2023-12-01
\.


--
-- Data for Name: User; Type: TABLE DATA; Schema: public; Owner: possum
--

COPY public."User" (username, password, name, birthday, email, preferred_size) FROM stdin;
Possum	Possumlore11	Lincoln	2001-11-10	ltp@shoe.com	11
Yadai4life	Yadai425	Yachty	2005-04-02	ymn@shoe.com	11
Possumprice	Possum420	Lincoln	2001-11-10	ltp@shoe.com	11
KSTXThatBoss	Kilroy69	Cole Kilroy	2001-12-10	ck@shoe.com	10
DrinkableYak	123SuckMyDik	Jack Hepurn	2001-10-11	jsh@shoe.com	10
RuggedDust2	mynameisbradyandunitedsux	Brady Aliabadi	2002-05-01	bja@shoe.com	12
glazedXdonut8	kb123420	Kai	2002-07-15	khb@shoe.com	10
Chainsaw1782	jeffjeff	Jake Markson	2002-02-10	jam@shoe.com	11
Scottlucas58	nuncweuhuiah842	Ty	2001-09-25	tl@shoe.com	12
Eddie2Rad	3hudh8hehsg	Eddie	2004-08-25	er@shoe.com	12
\.


--
-- Data for Name: listing; Type: TABLE DATA; Schema: public; Owner: possum
--

COPY public.listing (listing_id, size, shoe_sku, description, price, date) FROM stdin;
12208920	11	FD4810 061	Womens Air Jordan 1 Retro High OG Satin Bred 2023	177.00	2023-10-20
12208930	11	FV4921 600	Zoom Kobe 6 Proto Reverse Grinch	491.00	2023-12-01
12208935	13	FV4921 600	Zoom Kobe 6 Proto Reverse Grinch	604.00	2023-12-01
12208936	13	FV4921 600	Zoom Kobe 6 Proto Reverse Grinch	615.00	2023-12-02
12208962	11	508214 660	Air Yeezy 2 SP Red October	24995.00	2019-10-08
12208984	10	AQ4832	Yeezy Boost 350 Turtle Dove 2015	669.00	2021-10-10
12208990	9	BB550WTI	NB 550 White Green	117.00	2022-02-10
12208921	10	DH7695 600	Parra x Dunk Low Pro SB Abstract Art	291.00	2023-03-21
\.


--
-- Data for Name: order_shipment; Type: TABLE DATA; Schema: public; Owner: possum
--

COPY public.order_shipment (order_id, shipment_id) FROM stdin;
76250	487290
\.


--
-- Data for Name: review; Type: TABLE DATA; Schema: public; Owner: possum
--

COPY public.review (review_id, text, rating) FROM stdin;
3750090	This is the best seller of all time !!!	10
3750091	Scam, sold me a fake, stay far away	0
3750092	Shoe was used more than advertised	3
\.


--
-- Data for Name: sale_history; Type: TABLE DATA; Schema: public; Owner: possum
--

COPY public.sale_history (shoe_sku, name) FROM stdin;
\.


--
-- Data for Name: shipment; Type: TABLE DATA; Schema: public; Owner: possum
--

COPY public.shipment (shipment_id, tracking_number, address, distributor) FROM stdin;
487290	STD10023900	25237 N Horseshoe Trl	UPS
\.


--
-- Data for Name: shoe; Type: TABLE DATA; Schema: public; Owner: possum
--

COPY public.shoe (shoe_sku, quality, lowest_listing_price, manufacturer) FROM stdin;
FD4810 061	New	177.00	Nike
FV4921 600	New	491.00	Nike
508214 660	Used	14500.00	Nike
AQ4832	New	517.00	Adidas
BB550WTI	New	114.00	New Balance
DH7695 600	Used	291.00	Nike
\.


--
-- Data for Name: transaction; Type: TABLE DATA; Schema: public; Owner: possum
--

COPY public.transaction (transaction_id, sold_price, date, buyer_username, seller_username) FROM stdin;
11048	10000.00	2023-11-27	Possum	Chainsaw1782
\.


--
-- Data for Name: user_buys_listing; Type: TABLE DATA; Schema: public; Owner: possum
--

COPY public.user_buys_listing (username, listing_id) FROM stdin;
Possum	12208962
\.


--
-- Data for Name: user_posts_listing; Type: TABLE DATA; Schema: public; Owner: possum
--

COPY public.user_posts_listing (username, listing_id) FROM stdin;
Possum	12208920
DrinkableYak	12208930
Scottlucas58	12208935
Yadai4life	12208936
Chainsaw1782	12208962
Possumprice	12208984
Possum	12208990
KSTXThatBoss	12208921
\.


--
-- Data for Name: user_reviews; Type: TABLE DATA; Schema: public; Owner: possum
--

COPY public.user_reviews (username, review_id) FROM stdin;
Possumprice	3750090
DrinkableYak	3750091
Yadai4life	3750092
\.


--
-- Name: Order_order_id_seq; Type: SEQUENCE SET; Schema: public; Owner: possum
--

SELECT pg_catalog.setval('public."Order_order_id_seq"', 1, false);


--
-- Name: listing_listing_id_seq; Type: SEQUENCE SET; Schema: public; Owner: possum
--

SELECT pg_catalog.setval('public.listing_listing_id_seq', 1, false);


--
-- Name: review_review_id_seq; Type: SEQUENCE SET; Schema: public; Owner: possum
--

SELECT pg_catalog.setval('public.review_review_id_seq', 1, false);


--
-- Name: shipment_shipment_id_seq; Type: SEQUENCE SET; Schema: public; Owner: possum
--

SELECT pg_catalog.setval('public.shipment_shipment_id_seq', 1, false);


--
-- Name: transaction_transaction_id_seq; Type: SEQUENCE SET; Schema: public; Owner: possum
--

SELECT pg_catalog.setval('public.transaction_transaction_id_seq', 1, false);


--
-- Name: Order Order_pkey; Type: CONSTRAINT; Schema: public; Owner: possum
--

ALTER TABLE ONLY public."Order"
    ADD CONSTRAINT "Order_pkey" PRIMARY KEY (order_id);


--
-- Name: User User_pkey; Type: CONSTRAINT; Schema: public; Owner: possum
--

ALTER TABLE ONLY public."User"
    ADD CONSTRAINT "User_pkey" PRIMARY KEY (username);


--
-- Name: listing listing_pkey; Type: CONSTRAINT; Schema: public; Owner: possum
--

ALTER TABLE ONLY public.listing
    ADD CONSTRAINT listing_pkey PRIMARY KEY (listing_id);


--
-- Name: order_shipment order_shipment_pkey; Type: CONSTRAINT; Schema: public; Owner: possum
--

ALTER TABLE ONLY public.order_shipment
    ADD CONSTRAINT order_shipment_pkey PRIMARY KEY (order_id, shipment_id);


--
-- Name: review review_pkey; Type: CONSTRAINT; Schema: public; Owner: possum
--

ALTER TABLE ONLY public.review
    ADD CONSTRAINT review_pkey PRIMARY KEY (review_id);


--
-- Name: shipment shipment_pkey; Type: CONSTRAINT; Schema: public; Owner: possum
--

ALTER TABLE ONLY public.shipment
    ADD CONSTRAINT shipment_pkey PRIMARY KEY (shipment_id);


--
-- Name: shoe shoe_pkey; Type: CONSTRAINT; Schema: public; Owner: possum
--

ALTER TABLE ONLY public.shoe
    ADD CONSTRAINT shoe_pkey PRIMARY KEY (shoe_sku);


--
-- Name: transaction transaction_pkey; Type: CONSTRAINT; Schema: public; Owner: possum
--

ALTER TABLE ONLY public.transaction
    ADD CONSTRAINT transaction_pkey PRIMARY KEY (transaction_id);


--
-- Name: user_buys_listing user_buys_listing_pkey; Type: CONSTRAINT; Schema: public; Owner: possum
--

ALTER TABLE ONLY public.user_buys_listing
    ADD CONSTRAINT user_buys_listing_pkey PRIMARY KEY (username, listing_id);


--
-- Name: user_posts_listing user_posts_listing_pkey; Type: CONSTRAINT; Schema: public; Owner: possum
--

ALTER TABLE ONLY public.user_posts_listing
    ADD CONSTRAINT user_posts_listing_pkey PRIMARY KEY (username, listing_id);


--
-- Name: user_reviews user_reviews_pkey; Type: CONSTRAINT; Schema: public; Owner: possum
--

ALTER TABLE ONLY public.user_reviews
    ADD CONSTRAINT user_reviews_pkey PRIMARY KEY (username, review_id);


--
-- Name: order_shipment order_shipment_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: possum
--

ALTER TABLE ONLY public.order_shipment
    ADD CONSTRAINT order_shipment_order_id_fkey FOREIGN KEY (order_id) REFERENCES public."Order"(order_id);


--
-- Name: order_shipment order_shipment_shipment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: possum
--

ALTER TABLE ONLY public.order_shipment
    ADD CONSTRAINT order_shipment_shipment_id_fkey FOREIGN KEY (shipment_id) REFERENCES public.shipment(shipment_id);


--
-- Name: sale_history sale_history_shoe_sku_fkey; Type: FK CONSTRAINT; Schema: public; Owner: possum
--

ALTER TABLE ONLY public.sale_history
    ADD CONSTRAINT sale_history_shoe_sku_fkey FOREIGN KEY (shoe_sku) REFERENCES public.shoe(shoe_sku);


--
-- Name: transaction transaction_buyer_username_fkey; Type: FK CONSTRAINT; Schema: public; Owner: possum
--

ALTER TABLE ONLY public.transaction
    ADD CONSTRAINT transaction_buyer_username_fkey FOREIGN KEY (buyer_username) REFERENCES public."User"(username);


--
-- Name: transaction transaction_seller_username_fkey; Type: FK CONSTRAINT; Schema: public; Owner: possum
--

ALTER TABLE ONLY public.transaction
    ADD CONSTRAINT transaction_seller_username_fkey FOREIGN KEY (seller_username) REFERENCES public."User"(username);


--
-- Name: user_buys_listing user_buys_listing_listing_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: possum
--

ALTER TABLE ONLY public.user_buys_listing
    ADD CONSTRAINT user_buys_listing_listing_id_fkey FOREIGN KEY (listing_id) REFERENCES public.listing(listing_id);


--
-- Name: user_buys_listing user_buys_listing_username_fkey; Type: FK CONSTRAINT; Schema: public; Owner: possum
--

ALTER TABLE ONLY public.user_buys_listing
    ADD CONSTRAINT user_buys_listing_username_fkey FOREIGN KEY (username) REFERENCES public."User"(username);


--
-- Name: user_posts_listing user_posts_listing_listing_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: possum
--

ALTER TABLE ONLY public.user_posts_listing
    ADD CONSTRAINT user_posts_listing_listing_id_fkey FOREIGN KEY (listing_id) REFERENCES public.listing(listing_id);


--
-- Name: user_posts_listing user_posts_listing_username_fkey; Type: FK CONSTRAINT; Schema: public; Owner: possum
--

ALTER TABLE ONLY public.user_posts_listing
    ADD CONSTRAINT user_posts_listing_username_fkey FOREIGN KEY (username) REFERENCES public."User"(username);


--
-- Name: user_reviews user_reviews_review_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: possum
--

ALTER TABLE ONLY public.user_reviews
    ADD CONSTRAINT user_reviews_review_id_fkey FOREIGN KEY (review_id) REFERENCES public.review(review_id);


--
-- Name: user_reviews user_reviews_username_fkey; Type: FK CONSTRAINT; Schema: public; Owner: possum
--

ALTER TABLE ONLY public.user_reviews
    ADD CONSTRAINT user_reviews_username_fkey FOREIGN KEY (username) REFERENCES public."User"(username);


--
-- PostgreSQL database dump complete
--

